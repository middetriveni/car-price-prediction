import streamlit as st
import pandas as pd
import numpy as np
import pickle

# -------------------------
# Page Config
# -------------------------
st.set_page_config(page_title="Car Price Prediction", layout="wide")

# -------------------------
# Black & White CSS
# -------------------------
st.markdown("""
<style>
.main {
    background-color: #ffffff;
    color: #000000;
}

section[data-testid="stSidebar"] {
    background-color: #f5f5f5;
}

.title {
    text-align: center;
    font-size: 40px;
    font-weight: bold;
    color: black;
}

.subtitle {
    text-align: center;
    font-size: 26px;
    color: #333;
    margin-bottom: 30px;
}

label {
    color: black !important;
    font-weight: 500;
}

.stButton>button {
    background-color: black;
    color: white;
    border-radius: 8px;
    padding: 10px 20px;
    font-weight: bold;
}

.stButton>button:hover {
    background-color: #333;
}
</style>
""", unsafe_allow_html=True)

# -------------------------
# Load Data & Model
# -------------------------
df = pd.read_csv("cars24_data.csv")

model = pickle.load(open("car_price_model.pkl", "rb"))
# scaler = pickle.load(open("scaler.pkl", "rb"))

# -------------------------
# Sidebar
# -------------------------
# with st.sidebar:
#     st.markdown("### Select Options")
#     selected_model_sidebar = st.selectbox("Model", df['model'].unique())

# -------------------------
# Title
# -------------------------
st.markdown("<div class='title'>Car Price Prediction</div>", unsafe_allow_html=True)
st.markdown("<div class='subtitle'>Prediction Model Dashboard</div>", unsafe_allow_html=True)

# -------------------------
# Input Section
# -------------------------
col1, col2 = st.columns(2)

with col1:
    year = st.selectbox("Select Year", sorted(df['year'].unique()))
    model_name = st.selectbox("Select Car Model", df['model'].unique())
    km = st.number_input("Kilometers Driven", 0, 300000, 50000)
    owner = st.selectbox("Owner Number", df['ownernumber'].unique())

with col2:
    make = st.selectbox("Car Brand", df['make'].unique())
    transmission = st.selectbox("Transmission", df['transmission'].unique())
    fuel = st.selectbox("Fuel Type", df['fueltype'].unique())
    state = st.selectbox("Registration State", df['registrationstate'].unique())

# -------------------------
# Prediction Logic
# -------------------------
if st.button("Predict Price"):

    # Important features
    input_data = {
        'make': make,
        'model': model_name,
        'year': year,
        'fueltype': fuel,
        'kilometerdriven': km,
        'ownernumber': owner,
        'transmission': transmission,
        'bodytype': df[df['model'] == model_name]['bodytype'].iloc[0],
        'isc24assured': df[df['model'] == model_name]['isc24assured'].iloc[0],
        'discountprice': df[df['model'] == model_name]['discountprice'].mean()
    }

    input_df = pd.DataFrame([input_data])

    # Encoding
    input_df = pd.get_dummies(input_df)

    # Match training columns
    try:
        input_df = input_df.reindex(columns=scaler.feature_names_in_, fill_value=0)
    except:
        input_df = input_df.reindex(columns=model.feature_names_in_, fill_value=0)

    # Scaling
    # input_scaled = scaler.transform(input_df)

    # Prediction
    prediction = model.predict(input_df)

    # Output
    st.success(f"💰 Predicted Price: ₹{round(prediction[0],2)}")